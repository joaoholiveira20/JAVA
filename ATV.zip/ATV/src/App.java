import view.TelaLogin;

public class App {
    public static void main(String[] args) throws Exception {
        TelaLogin view = new TelaLogin();
        view.setVisible(true);
    }
}
