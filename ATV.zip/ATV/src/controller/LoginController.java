package controller;

import dao.UsuarioDAO;
import view.TelaLogin;
import view.TelaProduto;
import javax.swing.JOptionPane;

public class LoginController {
    private TelaLogin view;
    private UsuarioDAO dao;

    public LoginController(TelaLogin view) {
        this.view = view;
        this.dao = new UsuarioDAO();
    }

    public void autenticar() {
        String login = view.getTxtUsuario().getText();
        String senha = new String(view.getTxtSenha().getPassword());

        if (dao.validarLogin(login, senha)) {
            view.dispose();
            new TelaProduto().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(view, "Usuário ou senha inválidos!");
        }
    }
}