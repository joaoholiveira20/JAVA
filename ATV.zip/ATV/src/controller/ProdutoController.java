package controller;

import dao.ProdutoDAO;
import model.Produto;
import view.TelaProduto;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class ProdutoController {
    private TelaProduto view;
    private ProdutoDAO dao;

    public ProdutoController(TelaProduto view) {
        this.view = view;
        this.dao = new ProdutoDAO();
    }

    public void salvar() {
        try {
            int id = Integer.parseInt(view.getTxtId().getText());
            String nome = view.getTxtNome().getText();
            String cat = view.getTxtCategoria().getText();
            double preco = Double.parseDouble(view.getTxtPreco().getText());
            int qtd = Integer.parseInt(view.getTxtQtd().getText());

            Produto p = new Produto(id, nome, cat, preco, qtd);
            
            if (dao.buscarPorId(id) == null) {
                dao.cadastrar(p);
                JOptionPane.showMessageDialog(view, "Cadastrado com sucesso!");
            } else {
                dao.alterar(p);
                JOptionPane.showMessageDialog(view, "Alterado com sucesso!");
            }
            limparCampos();
            listar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Erro nos dados numéricos.");
        }
    }

    public void remover() {
        try {
            int id = Integer.parseInt(view.getTxtId().getText());
            dao.remover(id);
            limparCampos();
            listar();
            JOptionPane.showMessageDialog(view, "Removido com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Informe o ID para remover.");
        }
    }

    public void buscar() {
        try {
            int id = Integer.parseInt(view.getTxtId().getText());
            Produto p = dao.buscarPorId(id);
            if (p != null) {
                view.getTxtNome().setText(p.getNome());
                view.getTxtCategoria().setText(p.getCategoria());
                view.getTxtPreco().setText(String.valueOf(p.getPreco()));
                view.getTxtQtd().setText(String.valueOf(p.getQuantidade()));
            } else {
                JOptionPane.showMessageDialog(view, "Produto não encontrado.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Informe o ID para buscar.");
        }
    }

    public void listar() {
        List<Produto> lista = dao.listar();
        DefaultListModel<String> model = new DefaultListModel<>();
        for (Produto p : lista) {
            model.addElement(p.toString());
        }
        view.getListaProdutos().setModel(model);
    }

    private void limparCampos() {
        view.getTxtId().setText("");
        view.getTxtNome().setText("");
        view.getTxtCategoria().setText("");
        view.getTxtPreco().setText("");
        view.getTxtQtd().setText("");
    }
}