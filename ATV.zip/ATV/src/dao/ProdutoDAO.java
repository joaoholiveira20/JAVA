package dao;

import model.Produto;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {
    private ArrayList<Produto> produtos;

    public ProdutoDAO() {
        produtos = new ArrayList<>();
    }

    public void cadastrar(Produto p) {
        produtos.add(p);
    }

    public List<Produto> listar() {
        return produtos;
    }

    public Produto buscarPorId(int id) {
        for (Produto p : produtos) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public void alterar(Produto produtoAtualizado) {
        for (int i = 0; i < produtos.size(); i++) {
            if (produtos.get(i).getId() == produtoAtualizado.getId()) {
                produtos.set(i, produtoAtualizado);
                break;
            }
        }
    }

    public void remover(int id) {
        produtos.removeIf(p -> p.getId() == id);
    }
}