package dao;

import model.Usuario;
import java.util.ArrayList;

public class UsuarioDAO {
    private ArrayList<Usuario> usuarios;

    public UsuarioDAO() {
        usuarios = new ArrayList<>();
        // Usuário padrão para o login
        usuarios.add(new Usuario("admin", "1234"));
    }

    public boolean validarLogin(String login, String senha) {
        for (Usuario u : usuarios) {
            if (u.getLogin().equals(login) && u.getSenha().equals(senha)) {
                return true;
            }
        }
        return false;
    }
}