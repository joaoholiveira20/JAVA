package view;

import controller.LoginController;
import javax.swing.*;
import java.awt.*;

public class TelaLogin extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtSenha;
    private JButton btnEntrar;
    private LoginController controller;

    public TelaLogin() {
        setTitle("Login do Sistema");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2, 10, 10));

        add(new JLabel("Usuário:"));
        txtUsuario = new JTextField();
        add(txtUsuario);

        add(new JLabel("Senha:"));
        txtSenha = new JPasswordField();
        add(txtSenha);

        add(new JLabel("")); // Espaçador
        btnEntrar = new JButton("Entrar");
        add(btnEntrar);

        controller = new LoginController(this);
        btnEntrar.addActionListener(e -> controller.autenticar());
    }

    public JTextField getTxtUsuario() { return txtUsuario; }
    public JPasswordField getTxtSenha() { return txtSenha; }

    public static void main(String[] args) {
        new TelaLogin().setVisible(true);
    }
}