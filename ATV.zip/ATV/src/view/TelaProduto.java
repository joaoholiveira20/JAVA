package view;

import controller.ProdutoController;
import javax.swing.*;
import java.awt.*;

public class TelaProduto extends JFrame {
    private JTextField txtId, txtNome, txtCategoria, txtPreco, txtQtd;
    private JButton btnSalvar, btnRemover, btnBuscar, btnListar;
    private JList<String> listaProdutos;
    private ProdutoController controller;

    public TelaProduto() {
        setTitle("Cadastro de Produtos");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel painelForm = new JPanel(new GridLayout(6, 2, 5, 5));
        painelForm.add(new JLabel("ID:")); txtId = new JTextField(); painelForm.add(txtId);
        painelForm.add(new JLabel("Nome:")); txtNome = new JTextField(); painelForm.add(txtNome);
        painelForm.add(new JLabel("Categoria:")); txtCategoria = new JTextField(); painelForm.add(txtCategoria);
        painelForm.add(new JLabel("Preço:")); txtPreco = new JTextField(); painelForm.add(txtPreco);
        painelForm.add(new JLabel("Qtd Estoque:")); txtQtd = new JTextField(); painelForm.add(txtQtd);

        JPanel painelBotoes = new JPanel();
        btnSalvar = new JButton("Salvar"); btnRemover = new JButton("Remover");
        btnBuscar = new JButton("Buscar por ID"); btnListar = new JButton("Listar Todos");
        
        painelBotoes.add(btnSalvar); painelBotoes.add(btnRemover);
        painelBotoes.add(btnBuscar); painelBotoes.add(btnListar);
        
        painelForm.add(painelBotoes);
        
        add(painelForm, BorderLayout.NORTH);
        
        listaProdutos = new JList<>();
        add(new JScrollPane(listaProdutos), BorderLayout.CENTER);

        controller = new ProdutoController(this);

        btnSalvar.addActionListener(e -> controller.salvar());
        btnRemover.addActionListener(e -> controller.remover());
        btnBuscar.addActionListener(e -> controller.buscar());
        btnListar.addActionListener(e -> controller.listar());
    }

    public JTextField getTxtId() { return txtId; }
    public JTextField getTxtNome() { return txtNome; }
    public JTextField getTxtCategoria() { return txtCategoria; }
    public JTextField getTxtPreco() { return txtPreco; }
    public JTextField getTxtQtd() { return txtQtd; }
    public JList<String> getListaProdutos() { return listaProdutos; }
}